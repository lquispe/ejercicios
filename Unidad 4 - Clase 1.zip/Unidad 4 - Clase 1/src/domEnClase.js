document.getElementById("msjBienvenida").innerHTML = "Bienvenidos a DOM";
document.getElementById("msjBienvenida").style.backgroundColor = "blue";

var listaClases = document.getElementsByClassName("textoGrande");
console.log(listaClases);

function crearNota() {
    // cambiamos el texto html
    document.getElementById("nota").innerHTML = "Nota creada dinámicamente";

    // cambiamos el texto del botón
    document.getElementById("btnCrearNota").value = "Eliminar Nota";

    document.getElementById("btnCrearNota").onclick = "borrarNota()";
    
}

function borrarNota() {
    document.getElementById("nota").innerHTML = "";
}

